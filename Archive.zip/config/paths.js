const path = require('path');

module.exports = {
  root      : path.join(__dirname, '..'),
  app       : path.join(__dirname, '..', 'src'),
  dist      : path.join(__dirname, '..', 'dist'),
};
