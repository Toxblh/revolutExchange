/* eslint-disable global-require */
module.exports = {
  plugins: [
    require('autoprefixer')({
      browsers: ['last 1 versions']
    })
  ]
};
