import { takeEvery } from 'redux-saga';
import { put, call } from 'redux-saga/effects';
import * as api from '../api/api';
import { setCash } from '../redux/cash';
import { exchange } from '../redux/exchange';

export function* initCash() {
  try {
    const { data } = yield call(api.fetchCash);
    yield put(setCash(data));
  } catch (e) {
    console.error(e);
  }
}

export function* updateCash(action) {
  try {
    yield call(api.updateCash, action.payload.cash);
  } catch (e) {
    console.error(e);
  }
}

export function* updateCashWatcher() {
  yield* takeEvery(
    action => action.type === exchange.toString() && action.payload.valid,
    updateCash
  );
}
