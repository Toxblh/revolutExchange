import { createAction, handleActions } from 'redux-actions';
import { fromJS } from 'immutable';

const initialState = fromJS({
  from: 'USD',
  to: 'EUR',
  value: 0,
  currencies: ['EUR', 'USD', 'GBP']
});

export const changeValue = createAction(
  'CHANGE_VALUE',
  (value) => {
    const [originalHead, originalTail] = value.split('.');
    const hasDot = /^.+\./.test(value);
    const head = originalHead.replace(/\D/g, '');
    const tail = originalTail ? originalTail.replace(/\D/g, '') : '';
    return hasDot ? `${head}.${tail}` : head;
  }
);

export const exchange = createAction('EXCHANGE');
export const switchCurrency = createAction('SWITCH_CURRENCY');

export default handleActions({
  [changeValue](state, { payload }) {
    return state.set('value', payload);
  },

  [exchange](state, { payload }) {
    return payload.valid ? state.set('value', 0) : state;
  },

  [switchCurrency](state, { payload }) {
    return state.set(payload.direction, payload.currency);
  }
}, initialState);
