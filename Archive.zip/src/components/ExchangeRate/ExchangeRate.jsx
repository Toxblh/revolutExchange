import { PropTypes } from 'react';
import { getSymbolCode } from '../../utils/getSymbolCode';

import './exchangeRate.less';

const ExchangeRate = ({ codeFrom, codeTo, rate, ...rest }) => (
  <div {...rest}>
    { `${getSymbolCode(codeFrom)} 1 = ${getSymbolCode(codeTo)} ${rate}` }
  </div>
);

ExchangeRate.propTypes = {
  codeFrom: PropTypes.string,
  codeTo: PropTypes.string,
  rate: PropTypes.string
};

export default ExchangeRate;
