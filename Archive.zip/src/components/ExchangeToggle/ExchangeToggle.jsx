import { PropTypes } from 'react';

import './ExchangeToggle.less';

const ExchangeToggle = ({ currencies, to, from, onChange, ...rest }) => (
  <div className="currencies" {...rest}>
    {
      currencies.map((item) => {
        const classSelector = `currencies-item ${item == 1 ? 'currencies-item-active' : ''}`;
        return (<button
          key={item}
          className={classSelector}
          onClick={() => {
            onChange(item);
          }}
          disabled={item.active && item === to}
        >
          {item}
        </button>);
      }
      )
    }
  </div>
);

ExchangeToggle.propTypes = {
  onChange : PropTypes.func,
  currencies: PropTypes.array,
  from: PropTypes.string,
  to: PropTypes.string
};

export default ExchangeToggle;
