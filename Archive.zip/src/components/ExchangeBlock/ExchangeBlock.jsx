import { PropTypes, Component } from 'react';
import { isNumber } from '../../utils/isNumber';
import { formatMoney } from '../../utils/formatMoney';
import ExchangeRate from '../ExchangeRate/ExchangeRate';

import './ExchangeBlock.less';

class ExchangeBlock extends Component {
  static propTypes = {
    amount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    balance: PropTypes.number,
    code: PropTypes.string,
    error: PropTypes.string,
    from: PropTypes.bool,
    onChange: PropTypes.func,
    reverseFrom: PropTypes.string,
    reverseRate: PropTypes.string,
    reverseTo: PropTypes.string,
  };

  onInputChange = (event) => {
    if (!isNumber(event.currentTarget.value)) { return; }
    this.props.onChange(event.currentTarget.value);
  };

  render() {
    const { balance, from, code, reverseFrom, reverseTo, amount, error, reverseRate } = this.props;
    const classSelector = `exchange-block ${from ? 'exchange-block-from' : 'exchange-block-to'}`;

    return (
      <div className={classSelector}>
        <div className="exchange-block-row">
          <div className="exchange-block-currency-code">{code}</div>
          {
            from ?
              <input
                className="exchange-block-input"
                value={amount}
                placeholder="0.00"
                onChange={this.onInputChange}
              />
            :
              <span className="exchange-block-amount">{amount}</span>
          }
        </div>
        <div className="exchange-block-row">
          <div className="exchange-block-balance">
            You have {formatMoney(code, balance)}
          </div>
          {
            from ?
              <div className="exchange-block-error">
                {error}
              </div>
            :
              <div className="exchange-block-reverse-rates">
                <ExchangeRate
                  codeFrom={reverseFrom}
                  codeTo={reverseTo}
                  rate={reverseRate}
                />
              </div>
          }
        </div>
      </div>
    );
  }
}

export default ExchangeBlock;
