import { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import fx from 'money';
import ExchangeRate from './ExchangeRate/ExchangeRate';
import ExchangeBlock from './ExchangeBlock/ExchangeBlock';
import ExchangeButton from './ExchangeButton/ExchangeButton';
import ExchangeToggle from './ExchangeToggle/ExchangeToggle';

import '../assets/styles/normalize.css';
import './App.less';

class App extends Component {
  static propTypes = {
    base: PropTypes.string,
    rates: PropTypes.object,
    amountFrom: PropTypes.string,
    amountTo: PropTypes.string,
    from: PropTypes.string,
    to: PropTypes.string,
    currencies: PropTypes.string,
  }

  state = {
    amount: ''
  }

  getRates(from, to, base, rates, reverse = false, loaded = false) {
    if (!base || !loaded) { return; }
    fx.base = base;
    fx.rates = rates;

    const convertOptions = reverse
      ? { from: to, to: from }
      : { from, to };

    return fx.convert(1, convertOptions).toFixed(2, 10);
  }

  getExchangeValue() {

  }

  render() {
    const { from, base, rates, to, amountFrom, amountTo, currencies, loaded } = this.props;
    console.log(from, base, rates, to, amountFrom, amountTo, currencies);

    return (
      <div className="main">
        <ExchangeRate
          className="exchange-current-rate"
          codeFrom={from}
          codeTo={to}
          rate={this.getRates(from, to, base, rates, false, loaded)}
        />
        <ExchangeToggle
          onChange={() => {}}
          from={from}
          currencies={currencies}
        />
        <ExchangeBlock
          from
          amount=""
          code={from}
          balance={amountFrom}
          onChange={(value) => {
            this.setState({
              amount: value
            });
          }}
        />
        <ExchangeBlock
          code={to}
          reverseFrom={to}
          reverseTo={from}
          amount={this.getExchangeValue()}
          balance={amountTo}
          reverseRate={this.getRates(from, to, base, rates, true, loaded)}
          onChange={() => {}}
        />
        <ExchangeToggle
          onChange={() => {}}
          to={to}
          currencies={currencies}
        />
        <div className="exchange-wrap-button">
          <ExchangeButton
            onClick={() => {}}
          >
            Exchange
          </ExchangeButton>
        </div>
      </div>
    );
  }
}

export default connect(state => ({
  base: state.rates.get('base'),
  rates: state.rates.get('rates'),
  loaded: state.rates.get('fetch'),
  amountFrom: state.cash.get(state.exchange.get('from')),
  amountTo: state.cash.get(state.exchange.get('to')),
  from: state.exchange.get('from'),
  to: state.exchange.get('to'),
  currencies: state.exchange.get('currencies').toJS(),
}), { })(App);
