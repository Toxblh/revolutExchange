export const isNumber = value => /^[0-9]*[.]{0,1}[0-9]{0,2}$/.test(value);
